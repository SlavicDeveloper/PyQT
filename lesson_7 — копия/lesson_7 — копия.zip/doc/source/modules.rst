lesson_7
========

.. toctree::
   :maxdepth: 4

   client
   client
   common
   errors
   launcher
   launcher_mac
   launcher_mac_2
   launcher_ubuntu
   logs
   server
   server
   unit_tests
