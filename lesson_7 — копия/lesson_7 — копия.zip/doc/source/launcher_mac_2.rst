launcher\_mac\_2 module
=======================

.. automodule:: launcher_mac_2
   :members:
   :undoc-members:
   :show-inheritance:
