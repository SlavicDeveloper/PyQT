launcher\_ubuntu module
=======================

.. automodule:: launcher_ubuntu
   :members:
   :undoc-members:
   :show-inheritance:
