launcher\_mac module
====================

.. automodule:: launcher_mac
   :members:
   :undoc-members:
   :show-inheritance:
