errors module
=============

.. automodule:: errors
   :members:
   :undoc-members:
   :show-inheritance:
