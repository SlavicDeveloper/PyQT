launcher module
===============

.. automodule:: launcher
   :members:
   :undoc-members:
   :show-inheritance:
