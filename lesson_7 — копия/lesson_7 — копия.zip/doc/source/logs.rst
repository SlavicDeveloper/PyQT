logs package
============

Submodules
----------

logs.config\_client\_log module
-------------------------------

.. automodule:: logs.config_client_log
   :members:
   :undoc-members:
   :show-inheritance:

logs.config\_server\_log module
-------------------------------

.. automodule:: logs.config_server_log
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: logs
   :members:
   :undoc-members:
   :show-inheritance:
